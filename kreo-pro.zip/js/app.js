(() => {
  "use strict";
  let e = !1;
  setTimeout(() => {
    if (e) {
      let e = new Event("windowScroll");
      window.addEventListener("scroll", function (t) {
        document.dispatchEvent(e);
      });
    }
  }, 0);
  const t = document.querySelectorAll(".magnetic");
  t.forEach((e) => {
    e.addEventListener("mousemove", (t) => {
      const n = e.getBoundingClientRect(),
        o = t.pageX - n.left - n.width,
        i = t.pageY - n.top - n.height;
      e.style.transform = "translate(" + 0.3 * o + "px, " + 0.5 * i + "px)";
    });
  }),
    t.forEach((e) => {
      e.addEventListener("mouseout", (t) => {
        e.style.transform = "translate(0px, 0px)";
      });
    }),
    (window.FLS = !0),
    (function (e) {
      let t = new Image();
      (t.onload = t.onerror =
        function () {
          e(2 == t.height);
        }),
        (t.src =
          "data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA");
    })(function (e) {
      let t = !0 === e ? "webp" : "no-webp";
      document.documentElement.classList.add(t);
    });
})();
